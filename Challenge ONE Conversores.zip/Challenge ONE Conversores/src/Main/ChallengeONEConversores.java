/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import Vistas.Inicio;

/**
 *
 * @author Jeancarlos Barberena Morales
 * Creación de un conversor de temperaturas y 
 * de un conversor de monedas
 * 
 * CHALLENGE #2 DE ORACLE ONE
 */
public class ChallengeONEConversores {
    public static void main(String[] args) 
    {
        Inicio inicio = new Inicio();
        inicio.setVisible(true);
    }
}
